﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebDataSource.Implementation
{
    public class DataSoure
    {
       public static string Message= "Hello PersonalizationMall!";
    }
}