﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;

namespace WebDataSource.Implementation
{
    class ConsoleSource : WebDataSource.Interface.ISource
    {
        ILog iLoger = log4net.LogManager.GetLogger("ConsoleSource");
        public ConsoleSource()
        { }

        
        public string GetMessage()
        {
            iLoger.Info("GetMessage start");
            return DataSoure.Message;
        }

        public void WriteMessage(String message)
        {
            iLoger.Info("WriteMessage start");
            try
            {
                DataSoure.Message = message;
            }
            catch (Exception e)
            {
                iLoger.Error("WriteMessage: "+ e.Message);
            }
        }
    }
}
