﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDataSource.Interface
{
  public  interface ISource
    {
        /// <summary>
        /// return the message saved.
        /// </summary>
        /// <returns></returns>
        string GetMessage();
        /// <summary>
        /// update the message
        /// </summary>
        /// <param name="message"></param>
        void WriteMessage(String message);
    }
}
